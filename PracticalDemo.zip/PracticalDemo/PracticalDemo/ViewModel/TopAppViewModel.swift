
import Foundation

protocol TopAppViewModelProtocol {
    func insertFeedbackAPI(param:[String : Any]?,url:String,showLoader:Bool?,completion:@escaping ((_ status: StatusCode,_ feedModel: Feed, _ error: String?) -> ()))
}

class TopAppViewModel {

    func retriveUserDetail(param:[String : Any]?,url:String,showLoader:Bool?,completion:@escaping ((_ status: StatusCode,_ appModel: AppModel, _ error: String?) -> ())){
        APIManager.sharedInstance.callApi(url:url, method: .get, params: param, headers: nil, showLoader: true) { (code, resp, msg) in
            
            let response1 = (resp ?? [:]) as [String : Any]
            if let _appModel : AppModel = getObjectViaCodable(dict: response1) {
                completion(.success,_appModel,"")
            }
            else if let msg1 = resp?["msg"] as? String{
                completion(.error,AppModel(),msg1)
            }else{
                completion(.error,AppModel(),"")
            }
        }
    }
}
