

import Foundation
import Alamofire

typealias ResponseBlock = ((_ status: StatusCode,_ json: [String : Any]?, _ error: String?) -> ())


class APIManager: NSObject {
    struct ApiKeys {
        static let kData                = "data"
        static let kMembers             = "members"
        static let kUser              = "user"
    }
    static var sharedInstance: APIManager = APIManager()
    
    func callApi(url:String,method: HTTPMethod = .post,params:[String: Any]? = nil,headers:HTTPHeaders? = nil,showLoader: Bool? = true,completion : ResponseBlock? = nil){
        
        guard isConnectedToInternet() else {
//            completion?(.noInternet, nil, "No internet connection available.\nplease try again.")
            //UIApplication.topViewController()?.makeToastMsg("No internet connection available.\nplease try again.")
            return
        }
        
//        if showLoader! {
//            DispatchQueue.main.async {
//                showLoaderAnimate()
//            }
//        }
        
        //Disha Changes Start :- Print api URL
//        print(url)
        //Disha Changes End
        
        AF.request(url, method: method, parameters: params, encoding: URLEncoding.default, headers: headers, interceptor: nil, requestModifier: nil).responseJSON { (data) in
//            rPrint(data)
            
            let code: Int = data.response?.statusCode ?? 0
            var codeType: StatusCode = StatusCode(rawValue: code) ?? .noStatusCode
            if code == 201 {
                codeType = .success
            }
            
            if showLoader! {
//                DispatchQueue.main.async {
//                    hideLoaderAnimate()
//                }
            }
            
            switch data.result {
           
            case .success(let value):
                completion?(codeType, value as? [String: Any], nil)
                break;
            case .failure(let fError):
                
                if fError.responseCode == NSURLErrorTimedOut || data.response?.statusCode  == NSURLErrorTimedOut {
                    completion?(.timeOut, nil, "Request Time out")
                } else if fError.isSessionTaskError {
                    completion?(.error, nil, "Could not connect to the server")
                }  else if fError.isExplicitlyCancelledError {
                    completion?(.requestCancelled, nil, nil)
                } else {
                    /// if fails then check data from server
                    if let jsonRawData = data.data {
                        do {
                            /// If error data it is n
                            /// ot json serialized
                            let json = try JSONSerialization.jsonObject(with: jsonRawData, options: [])
                            let errStr: String? = ((json as? [String: Any])?["message"] as? String) ?? fError.localizedDescription
                            completion?(codeType, json as? [String: Any], errStr)
                        }
                        catch let err {
                            // then throm with error description
                            completion?(codeType, nil, err.localizedDescription)
                        }
                    } else {
                        completion?(codeType, nil, fError.localizedDescription)
                    }
                }
                break;
            }
        }
    }
}
extension Encodable {
    var dictionary: [String: Any]? {
        guard let data = try? JSONEncoder().encode(self) else { return nil }
        return (try? JSONSerialization.jsonObject(with: data, options: .allowFragments)).flatMap { $0 as? [String: Any] }
    }
}
public func isConnectedToInternet() -> Bool {
    return NetworkReachabilityManager()?.isReachable ?? false
}
