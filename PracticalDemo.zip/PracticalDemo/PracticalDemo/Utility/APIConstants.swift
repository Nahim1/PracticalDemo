

import Foundation
import UIKit

enum StatusCode: Int {
    case success          = 200 // OK for success
    case error            = 400 // Bad request for wrong parameters
    case unauthorized     = 401 // Thrown due to token mismatch or expiration
    case tokenRefreshed   = -1  // When token expires nd token refresh is call, then in response this code will be sent.
    case noContent        = 204 // No content when everything goes right but there is no data to be shown.
    case resourceNotFound = 404 // When Resource is not found
    case codeError        = 500 // Where we(backend) have messed up the code
    case unsupportedMedia = 415 // Unsupported Media Type
    case timeOut          = -2  // Time out
    case requestCancelled = -3  // Request Cancelled
    case noStatusCode     = 0   // If any other above code is obtained
    case noInternet       = -4  // No internet available
}


