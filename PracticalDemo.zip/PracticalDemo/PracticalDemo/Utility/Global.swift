//
//  Global.swift
//  RomanticThings
//
//  Created by Payal on 22/07/21.
//

import Foundation
import UIKit

extension String { //Storyboard name
    static let MainStoryboard           = "Main"
}

//MARK: - CODABLE FUNCTIONS
func getObjectViaCodable<T : Codable>(dict : [String : Any]) -> T? {
    if let jsonData = try? JSONSerialization.data(
        withJSONObject: dict,
        options: .prettyPrinted
        ){
        do {
            let posts = try JSONDecoder().decode(T.self, from: jsonData)
            return posts
        } catch {
            print(error)
            return nil
        }
        
    } else {
        return nil
    }
}
func getArrayViaCodable<T : Codable>(arrDict : [[String : Any]]) -> [T]? {
    if let jsonData = try? JSONSerialization.data(
        withJSONObject: arrDict,
        options: .prettyPrinted
        ){
        do {
            let posts = try JSONDecoder().decode([T].self, from: jsonData)
            return posts
        } catch {
            print(error)
            return nil
        }
    } else {
        return nil
    }
}
