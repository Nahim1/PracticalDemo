//
//  ViewController.swift
//  PracticalDemo
//
//  Created by Nahim on 26/12/22.
//

import UIKit

class TopAppListVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

