
import UIKit

class TopAppListVC: UIViewController {
    var appList : [Entry] = []
    var filteredAppList : [Entry] = []
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var txtField: UITextField!
    
    @IBOutlet weak var lblNoSearchResult: UILabel!
    @IBOutlet weak var lblRights: UILabel!
    let cellReuseIdentifier = "AppCell"
    lazy var viewModel : TopAppViewModel = {
        return TopAppViewModel()
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        initConfig()
        self.retriveAppListAPI()
    }


}
//MARK: TaleView Methods
extension TopAppListVC : UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredAppList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:AppCell = tableView.dequeueReusableCell(withIdentifier: "AppCell") as! AppCell
        cell.setUpCellData(entry: filteredAppList[indexPath.row])
        return cell

    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard: UIStoryboard = UIStoryboard(name: .MainStoryboard, bundle: nil)
        let detailVC = storyboard.instantiateViewController(withIdentifier: "DetailVC") as! DetailVC
        detailVC.entry = filteredAppList[indexPath.row]
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
}
//MARK: Custom Methods
extension TopAppListVC {
    func initConfig() {
        self.tblView.register(UINib(nibName: "AppCell", bundle: nil), forCellReuseIdentifier: "AppCell")
        lblNoSearchResult.isHidden = true
        tblView.isHidden = true
        txtField.addTarget(self, action: #selector(TopAppListVC.textFieldDidChange(_:)),
                                  for: .editingChanged)

    }
}
//MARK:- API Call
extension TopAppListVC {
    func retriveAppListAPI(showLoader: Bool? = true){
        let url = "https://itunes.apple.com/us/rss/toppaidapplications/limit=200/json"
        self.viewModel.retriveUserDetail(param: [:], url:url, showLoader: showLoader) { [weak self](code, response, msg) in
            if code == .success {
               print(response)
                self?.appList = response.feed?.entries ?? []
                self?.filteredAppList = self?.appList ?? []
                self?.title = response.feed?.titles?.text
                self?.lblRights.text = response.feed?.appleRights?.text
                self?.tblView.isHidden = false
                self?.tblView.reloadData()
            } else {
                let alertController = UIAlertController(title: "Error", message: "Server Error", preferredStyle: .alert)
                let OKAction = UIAlertAction(title: "OK", style: .default) { action in
                }
                alertController.addAction(OKAction)
                self?.present(alertController, animated: true, completion: nil)
            }
        }
    }
}
//MARK: TextField Methods
extension TopAppListVC {
    @objc func textFieldDidChange(_ textField: UITextField) {
        if let text = textField.text {
            if text.count > 0 {
                filteredAppList = appList.filter { $0.title?.name.lowercased().contains(text) ?? false || $0.category?.categoryAttribute?.name.lowercased().contains(text) ?? false }

            } else {
                filteredAppList = appList
            }
        } else {
            filteredAppList = appList
        }
        tblView.isHidden = true
        lblNoSearchResult.isHidden = true
        if filteredAppList.count <= 0 {
            lblNoSearchResult.isHidden = false
        } else {
            tblView.isHidden = false
        }
        tblView.reloadData()
    }

}
