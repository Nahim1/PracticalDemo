
import UIKit
import SDWebImage

class AppCell: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var iv: SDAnimatedImageView!
    var indexPath = IndexPath()
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    func setUpCellData(entry : Entry) {
        lblName.text = entry.title?.name
        iv.sd_setImage(with: URL(string: entry.images.first!.link) , placeholderImage: nil)
    }
}
