
import UIKit
import SDWebImage
class DetailVC: UITableViewController {
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var lblSummary: UILabel!
    @IBOutlet weak var iv: SDAnimatedImageView!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblContentType: UILabel!
    
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var lblRights: UILabel!
    var entry : Entry = Entry()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        bindData()
        initConfig()
    }


}
//MARK: Custom Methods
extension DetailVC {
    func initConfig() {
        self.title = entry.title?.name
    }
    func bindData() {
        lblContentType.text = entry.contentType?.contentTypeAttribute?.name
        lblPrice.text = entry.price?.text
        iv.sd_setImage(with: URL(string: entry.images.first!.link) , placeholderImage: nil)
        lblRights.text = entry.rights?.text
        lblCategory.text = entry.category?.categoryAttribute?.name
        lblSummary.text = entry.summary?.text
    }
}
