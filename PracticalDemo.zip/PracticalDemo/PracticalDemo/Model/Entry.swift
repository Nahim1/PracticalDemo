

import UIKit

class Entry: NSObject, Codable {
    var title: Title?
    var images : [Image] = []
    var category : Category?
    var contentType : ContentType?
    var summary : Summary?
    var price : Price?
    var rights : Rights?
    enum CodingKeys: String, CodingKey {
        case title = "im:name"
        case images = "im:image"
        case category = "category"
        case summary = "summary"
        case price = "im:price"
        case rights = "rights"
        case contentType = "im:contentType"

    }
    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.title) {
            title =  try container.decode(Title.self, forKey: .title)
        }
        if container.contains(.images) {
            images =  try container.decode([Image].self, forKey: .images)
        }
        if container.contains(.category) {
            category =  try container.decode(Category.self, forKey: .category)
        }
        if container.contains(.price) {
            price =  try container.decode(Price.self, forKey: .price)
        }
        if container.contains(.rights) {
            rights =  try container.decode(Rights.self, forKey: .rights)
        }
        if container.contains(.summary) {
            summary =  try container.decode(Summary.self, forKey: .summary)
        }
        if container.contains(.contentType) {
            contentType =  try container.decode(ContentType.self, forKey: .contentType)
        }
    }
}
class Title: NSObject, Codable {
    var name: String = ""
    enum CodingKeys: String, CodingKey {
        case name = "label"
    }
    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.name) {
            name =  try container.decode(String.self, forKey: .name)
        }
    }
}
class Image: NSObject, Codable {
    var link: String = ""
    enum CodingKeys: String, CodingKey {
        case link = "label"
    }
    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.link) {
            link =  try container.decode(String.self, forKey: .link)
        }
    }
}
class Category: NSObject, Codable {
    var categoryAttribute: CategoryAttribute?
    enum CodingKeys: String, CodingKey {
        case categoryAttribute = "attributes"
    }
    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.categoryAttribute) {
            categoryAttribute =  try container.decode(CategoryAttribute.self, forKey: .categoryAttribute)
        }
    }
}
class CategoryAttribute: NSObject, Codable {
    var name: String = ""
    enum CodingKeys: String, CodingKey {
        case name = "label"
    }
    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.name) {
            name =  try container.decode(String.self, forKey: .name)
        }
    }
}
class ContentType: NSObject, Codable {
    var contentTypeAttribute: ContentTypeAttribute?
    enum CodingKeys: String, CodingKey {
        case contentTypeAttribute = "attributes"
    }
    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.contentTypeAttribute) {
            contentTypeAttribute =  try container.decode(ContentTypeAttribute.self, forKey: .contentTypeAttribute)
        }
    }
}
class ContentTypeAttribute: NSObject, Codable {
    var name: String = ""
    enum CodingKeys: String, CodingKey {
        case name = "label"
    }
    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.name) {
            name =  try container.decode(String.self, forKey: .name)
        }
    }
}
class Summary: NSObject, Codable {
    var text: String = ""
    enum CodingKeys: String, CodingKey {
        case text = "label"
    }
    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.text) {
            text =  try container.decode(String.self, forKey: .text)
        }
    }
}
class Price: NSObject, Codable {
    var text: String = ""
    enum CodingKeys: String, CodingKey {
        case text = "label"
    }
    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.text) {
            text =  try container.decode(String.self, forKey: .text)
        }
    }
}
class Rights: NSObject, Codable {
    var text: String = ""
    enum CodingKeys: String, CodingKey {
        case text = "label"
    }
    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.text) {
            text =  try container.decode(String.self, forKey: .text)
        }
    }
}
