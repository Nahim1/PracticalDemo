
import UIKit

class Titles: NSObject, Codable {
    var text: String = ""
    enum CodingKeys: String, CodingKey {
        case text = "label"
    }
    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.text) {
            text =  try container.decode(String.self, forKey: .text)
        }
    }
}

