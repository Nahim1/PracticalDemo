
import UIKit
class AppModel: NSObject, Codable {
    var feed: Feed?
    enum CodingKeys: String, CodingKey {
        case feed = "feed"
    }
    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.feed) {
            feed =  try container.decode(Feed.self, forKey: .feed)
        }
    }
}
class Feed: NSObject, Codable {
    var author: Author?
    var entries: [Entry] = []
    var appleRights: AppleRights?
    var titles: Titles?

    
    enum CodingKeys: String, CodingKey {
        case entries = "entry"
        case titles = "title"
        case appleRights = "rights"

    }
    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.entries) {
            entries =  try container.decode([Entry].self, forKey: .entries)
        }
        if container.contains(.appleRights) {
            appleRights =  try container.decode(AppleRights.self, forKey: .appleRights)
        }
        if container.contains(.titles) {
            titles =  try container.decode(Titles.self, forKey: .titles)
        }
    }
}

class Author: NSObject, Codable {
    var name: Name?
    enum CodingKeys: String, CodingKey {
        case name = "name"
    }
    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.name) {
            name =  try container.decode(Name.self, forKey: .name)
        }
    }
}
class Name: NSObject, Codable {
    var name: String = ""
    enum CodingKeys: String, CodingKey {
        case name = "label"
    }
    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.name) {
            name =  try container.decode(String.self, forKey: .name)
        }
    }
}

